document.getElementById("sign-up-btn").addEventListener("click", function() {
    handleAuth('Sign Up');
});

document.getElementById("log-in-btn").addEventListener("click", function() {
    handleAuth('Log In');
});

function handleAuth(action) {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    
    if (username && password) {
        alert(`${action} successful!`);
        document.getElementById("auth-page").style.display = "none";
        document.getElementById("main-content").style.display = "block";
    } else {
        alert("Please enter both username and password.");
    }
}

function showProfile() {
    hideAllPages();
    document.getElementById("profile-page").style.display = "block";
}

function showRegistration() {
    hideAllPages();
    document.getElementById("registration-page").style.display = "block";
}

function showNotifications() {
    hideAllPages();
    document.getElementById("notifications-page").style.display = "block";
}

function showSettings() {
    hideAllPages();
    document.getElementById("settings-page").style.display = "block";
}

function showLogoutConfirmation() {
    hideAllPages();
    document.getElementById("logout-page").style.display = "block";
}

document.getElementById("logout-yes").addEventListener("click", function() {
    logout();
});

document.getElementById("logout-no").addEventListener("click", function() {
    hideAllPages();
    document.getElementById("profile-page").style.display = "block";
});

function logout() {
    document.getElementById("auth-page").style.display = "block";
    document.getElementById("main-content").style.display = "none";
}

function hideAllPages() {
    document.querySelectorAll(".page").forEach(page => {
        page.style.display = "none";
    });
}

document.getElementById("registration-form").addEventListener("submit", function(event) {
    event.preventDefault();
    const name = document.getElementById("full-name").value;
    const email = document.getElementById("email").value;

    const listItem = document.createElement("li");
    listItem.innerHTML = `${name} - ${email} <button onclick="removeUser(this)">Remove</button>`;
    document.getElementById("registration-list").appendChild(listItem);

    document.getElementById("registration-form").reset();
});

function removeUser(button) {
    const listItem = button.parentElement;
    listItem.remove();
}

function addDevice() {
    const stream = document.getElementById("device-stream");
    stream.innerHTML = `<iframe src="http://your-esp32-cam-url" width="320" height="240"></iframe>`;
}
